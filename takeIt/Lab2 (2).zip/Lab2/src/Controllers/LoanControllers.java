package Controllers;

import Records.BankRecords;
import models.daoModel;
import views.LoanView;

public class LoanControllers extends BankRecords {

	public static void main (String[] args)throws Throwable{
		//create objects 
		BankRecords br = new BankRecords();
		daoModel dm = new daoModel();
		//read data from BankRecords
		br.readData();
		//call create table
		dm.createTable();
		//call  insert table method
		dm.inserts(robjs);
		 new LoanView();
	
	}
	
	
	
}
