
import java.util.Comparator;

public class MaxMinComparator implements Comparator<BankRecords> {

	@Override
	public int compare(BankRecords o1, BankRecords o2) {
		// TODO Auto-generated method stub
		
		
		int result=  Float.valueOf(o1.getIncome()).compareTo(Float.valueOf(o2.getIncome()));
		return result;
	}
	

}
