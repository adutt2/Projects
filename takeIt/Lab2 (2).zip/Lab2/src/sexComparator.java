import java.util.Comparator;  
public class sexComparator implements Comparator<BankRecords> {

	public int compare(BankRecords o1,BankRecords o2){
		return o1.getSex().compareTo(o2.getSex());
	}
}
