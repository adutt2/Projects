package models;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;


 public class Connector {
	
	 public Connection getConnection() throws ClassNotFoundException{
		 Connection conn=null;
		 try{
		Class.forName("com.mysql.jdbc.Driver");	 
		 
	//String URL = "jdbc:mysql://www.papademas.net:3306/510labs";
	//String USER = "db510";
	//String PASS = "510";
	 conn = DriverManager.getConnection("jdbc:mysql://www.papademas.net/510labs?"+"user=db510&password=510");
	}
		 catch(SQLException e){
			 System.out.println(e.getMessage());
			 }
		return conn;
		 }
		 }

