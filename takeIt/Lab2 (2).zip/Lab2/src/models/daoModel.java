package models;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Records.BankRecords;

public class daoModel extends BankRecords {
	Connector conn = new Connector();
	private Statement  statement= null;
	
	
	public  void createTable() throws SQLException{
		try{
			//create object and call class methods
			statement	=	conn.getConnection().createStatement();
			//pass sql statement
			String sql= "CREATE TABLE z_saye_tab"+
						"(pid INTEGER not NULL  AUTO_INCREMENT,"+
						"id VARCHAR(20),"+
						"income NUMERIC(8,2),"+
						"pep VARCHAR(3),"+
						"PRIMARY KEY (pid))";
			statement.executeUpdate(sql);
			System.out.println("Created table in given database...");
			//close connection
			statement.close();
		}
		catch(SQLException e){
			System.out.print(e.getMessage());
		}
		catch(ClassNotFoundException e){
			
		}
	
	}
	
	public void inserts( BankRecords [] robjs)throws Exception {
		
		try{
			//call the connection object in Connector Class
			statement=conn.getConnection().createStatement();
			//initiate the string to be passed in the sql
			String sql="NULL";
			for(int i=0;i<robjs.length;i++)
			{
				sql="INSERT INTO z_saye_tab(id,income,pep)"+
					"VALUES('"+robjs[i].getId()+"','"+robjs[i].getIncome()+"','"+robjs[i].getPep()+"')";
				statement.executeUpdate(sql);
			}
			//print for acknowledgement
			System.out.println("Inserted records into the table...");
			}	
		catch(SQLException e){
			System.out.println(e.getMessage());
		}
		
	}
	
	
		public ResultSet getResultSet() throws Exception {
			  ResultSet rs = null;
			    try {
			    	 statement = conn.getConnection().createStatement();
			    	 //pass the sql statement
			    	 String sql = "select * from z_saye_tab";
			    	 
			    	 rs = statement.executeQuery(sql);
			   		    	 	         
				  } catch (SQLException e) {
				    System.out.println(e.getMessage());  
				  }
			//retirn value of object
				return rs;  
				
			}

		
		
	}
	


