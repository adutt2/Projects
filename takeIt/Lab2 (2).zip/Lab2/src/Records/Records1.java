package Records;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.io.IOException;
import java.util.Arrays;

public class Records1 extends BankRecords{
	
	//CREATE FILE WRITER OBJECT
	private static FileWriter fw =null;
	//CREATE RECORDS OBJECT TO WRITE IN TO bankrecords.txt
	public Records1()
	{
		try{
		fw= new FileWriter("bankrecords1.txt");
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
//CREATE AVERAGE COMPARATOR FOR ADDING SUM ACCORDING TO REGION
	private static void AverageComparator(){
		Arrays.sort(robjs,new AvgComparator());
		float sum1=0,sum2=0,sum3=0,sum4=0;
		double res1=0,res2=0,res3=0,res4=0;
		for (int i = 0;i<robjs.length;i++)
			if(robjs[i].getRegion().equals("RURAL"))//CHECKING FOR CONDTIONS AS REQUIRED ACCORDING TO REGIONS
			{
				sum1+=robjs[i].getIncome();  // SIMULTANEOULSY ADDING INTO THE SUM AS PER EACH LOCATION
				
			}
			else if (robjs[i].getRegion().equals("INNER_CITY"))
				{
					sum2+=robjs[i].getIncome();
				}	 
		
			else if (robjs[i].getRegion().equals("TOWN"))
			{
				sum3+=robjs[i].getIncome();
				 }
		
			else sum4+=robjs[i].getIncome();
				
				 
				res1=sum1/robjs.length;
					System.out.printf("Average income in RURAL is :$%5.2f\n",res1);
					
					res2=sum2/robjs.length;
					System.out.printf("Average income in INNER CITY is :$%5.2f\n",res2);		
	
					res3=sum3/robjs.length;
					System.out.printf("Average income in TOWN is :$%5.2f\n",res3);
					
					res4=sum4/robjs.length;
					System.out.printf("Average income in SURBUBAN is :$%5.2f\n",res4);
	try{
		//WRITING DOWN IN TXT FILE
		fw.write(String.format("Average income in RURAL is :$%5.2f\n",res1)+"\n");
		fw.write(String.format("Average income in INNER CITY is :$%5.2f\n",res2)+"\n");
		fw.write(String.format("Average income in TOWN is :$%5.2f\n",res3)+"\n");
		fw.write(String.format("Average income SURBUBANis :$%5.2f\n",res4)+"\n");
	}
	catch(IOException e)
	{e.printStackTrace();}
	}
	
public static void maleComparator(){
	Arrays.sort(robjs,new MalesComparator());
	int tcount=0,ccount=0,rcount=0,scount=0;
	for(int i=0;i<robjs.length;++i)
		//CHECKING FOR CONDTIONS AS REQUIRED ACCORDING TO SEX AND CARS AND CHILDREN
		{if(robjs[i].getSex().equals("MALE")&& robjs[i].getCar().equals("YES")&& robjs[i].getChildren().equals("1") )

		{	//CHECKING FOR CONDTIONS AS REQUIRED ACCORDING TO REGIONS
			if(robjs[i].getRegion().equals("TOWN") )
				{tcount++;}
		//ASSIGNING COUNT TO PRINT THE NUMBER IN THE END
				else 	if(robjs[i].getRegion().equals("INNER_CITY"))
			 		{ccount++;}
				else if (robjs[i].getRegion().equals("RURAL"))
		 			{rcount++;}
				else if(robjs[i].getRegion().equals("SUBURBAN"))
				 {scount++;}
		 
		
	//	System.out.println(robjs[i].getId()+"	"+robjs[i].getSex()+"	"+robjs[i].getCar()+"	"+robjs[i].getChildren());
		}
}		
System.out.println("total female count in town :"+tcount);	
System.out.println("total female count in inner city is :"+ccount);
System.out.println("total female count in rural is :"+rcount);
System.out.println("total female count in suburban is :"+scount);
try{
	//WRITING DOWN IN TXT FILE
	fw.write(String.format("number of males with both a car and 1 child in RURAL is :%d",+rcount)+"\n");
	fw.write(String.format("number of males with both a car and 1 child  in INNER CITY is :%d",+ccount)+"\n");
	fw.write(String.format("number of males with both a car and 1 child in TOWN is :%d",+tcount)+"\n");
	fw.write(String.format("number of males with both a car and 1 child in SURBUBANis :%d",+scount)+"\n");
}
catch(IOException e)
{e.printStackTrace();
}
}

	
	
public static void femaleComparator() throws IOException{
	Arrays.sort(robjs,new FemaleComparator());
	int tcount=0,ccount=0,rcount=0,scount=0;
	for(int i=0;i<robjs.length;++i)
		{
		//CHECKING FOR CONDTIONS AS REQUIRED ACCORDING TO SEX, MORTGAGE AND SAVINGS ACCOUNT
		if(robjs[i].getSex().equals("FEMALE")&& robjs[i].getMortgage().equals("YES")&& robjs[i].getSaveact().equals("YES") )
			{	
			//CHECKING FOR CONDTIONS AS REQUIRED ACCORDING TO REGIONS
				if(robjs[i].getRegion().equals("TOWN") )
					{
					//ASSIGNING COUNT TO PRINT THE NUMBER IN THE END
					tcount++;}
			
					else 	if(robjs[i].getRegion().equals("INNER_CITY"))
				 		{ccount++;}
					else if (robjs[i].getRegion().equals("RURAL"))
			 			{rcount++;}
					else if(robjs[i].getRegion().equals("SUBURBAN"))
					 {scount++;}
			 
			
		//	System.out.println(robjs[i].getId()+"	"+robjs[i].getSex()+"	"+robjs[i].getMortgage()+"	"+robjs[i].getSaveact());
			}
			}		
System.out.println("total female count in town :"+tcount);	
System.out.println("total female count in inner city is :"+ccount);
System.out.println("total female count in rural is :"+rcount);
System.out.println("total female count in suburban is :"+scount);
try{
	
	//WRITING INTO TXT FILE AS REQUIRED
	fw.write(String.format("number of females with both a mortgage and savings account in RURAL is :%d",rcount)+"\n");
	fw.write(String.format("number of females with both a mortgage and savings account in INNER CITY is :%d",ccount)+"\n");
	fw.write(String.format("number of females with both a mortgage and savings account is :%d",tcount)+"\n");
	fw.write(String.format("number of females with both a mortgage and savings accounts in SURBUBANis :%d",rcount)+"\n");
}
catch(IOException e)
{e.printStackTrace();
}
	}

private static void maxminComparator() throws IOException {
	// TODO Auto-generated method stub
	float INNER_CITYmax=0f,TOWNmax=0f,SUBURBANmax=0f,RURALmax=0f;
	float INNER_CITYmin=0,TOWNmin=0,SUBURBANmin=0,RURALmin=0;
	Arrays.sort(robjs,new MaxMinComparator());
	//ITERATING FOR MINIIMUM
	for(int  i=0;i<robjs.length;i++)
	{
		//CHECKING FOR CONDTIONS AS REQUIRED ACCORDING TO REGIONS
	if(robjs[i].getRegion().equals("TOWN") && TOWNmin==0)
	{
		//SAVE THE VALUE IN THE TEMP VARIABLE INITIATED ABOVE
		TOWNmin=robjs[i].getIncome();
		
	}
	//SIMILARLY FOR ALL REGIONS
	else if(robjs[i].getRegion().equals("INNER_CITY") && INNER_CITYmin==0)
	{
		INNER_CITYmin=robjs[i].getIncome();
	
		//SIMILARLY FOR ALL REGIONS
	}
	else if(robjs[i].getRegion().equals("SUBURBAN") && SUBURBANmin==0)
	{
		//SAVE THE VALUE IN THE TEMP VARIABLE INITIATED ABOVE
		SUBURBANmin=robjs[i].getIncome();
		
	}
	//SIMILARLY FOR ALL REGIONS
	else if(robjs[i].getRegion().equals("RURAL")&&RURALmin==0)
	{
		//SAVE THE VALUE IN THE TEMP VARIABLE INITIATED ABOVE
		RURALmin=robjs[i].getIncome();	
	}
	}
System.out.println("TOWNmin "+TOWNmin);
System.out.println("INNER_CITYmin "+INNER_CITYmin);
System.out.println("SUBURBANmin "+SUBURBANmin);
System.out.println("RURALmin "+RURALmin);


//ITERATING FOR MAXIMUM
		for(int  i=robjs.length-1;i>0;i--)
		{
			//CHECKING FOR CONDTIONS AS REQUIRED ACCORDING TO REGIONS
	
		if(robjs[i].getRegion().equals("TOWN") && TOWNmax==0)
		{
			//SAVE THE VALUE IN THE TEMP VARIABLE INITIATED ABOVE
			TOWNmax=robjs[i].getIncome();	
		}
		//SIMILARLY FOR ALL THE REGIONS
		else if(robjs[i].getRegion().equals("INNER_CITY") && INNER_CITYmax==0)
		{
			//SAVE THE VALUE IN THE TEMP VARIABLE INITIATED ABOVE
			INNER_CITYmax=robjs[i].getIncome();
			
		}
		else if(robjs[i].getRegion().equals("SUBURBAN") && SUBURBANmax==0)
		{
			SUBURBANmax=robjs[i].getIncome();
			
		}
		else if(robjs[i].getRegion().equals("RURAL") && RURALmax==0)
		{
			RURALmax=robjs[i].getIncome();
			
		}
		
		}
	
	System.out.println("TOWNmax "+TOWNmax);
	System.out.println("INNER_CITYmax "+INNER_CITYmax);
	System.out.println("SUBURBANmax "+SUBURBANmax);
	System.out.println("RURALmax "+RURALmax);
	
	try{
	//WRITE INTO TXT FILE MAXIMUMS
	fw.write(String.format("MAX income in RURAL is :$%5.2f\n",RURALmax)+"\n");
	fw.write(String.format("MAX income in INNER CITY is :$%5.2f\n",INNER_CITYmax)+"\n");
	fw.write(String.format("MAX income in TOWN is :$%5.2f\n",TOWNmax)+"\n");
	fw.write(String.format("MAX income SURBUBANis :$%5.2f\n",SUBURBANmax)+"\n");
	//WRITE INTO TXT FILE MINIMUMS
	fw.write(String.format("MIN income in RURAL is :$%5.2f\n",RURALmin)+"\n");
	fw.write(String.format("MIN income in INNER CITY is :$%5.2f\n",INNER_CITYmin)+"\n");
	fw.write(String.format("MIN income in TOWN is :$%5.2f\n",TOWNmin)+"\n");
	fw.write(String.format("MIN income SURBUBANis :$%5.2f\n",SUBURBANmin)+"\n");
	}
	catch(IOException e)
	{e.printStackTrace();
	}
}

public static void main (String[] args)throws IOException{
	
	
	Records1 r = new Records1();
	//CALL READ DATA
	r.readData();
	fw.write("AVERAGE INCOME IS AS FOLLOWS\n-----------------------------\n");
	//CALL AVERAGE COMPARATOR
	AverageComparator();
	fw.write("MAX AND MIN INCOME AS PER LOCATION\n-----------------------------\n");
	
	//SIMILARLY CALL FOR EVERY METHOD
	maxminComparator();
	fw.write("FEMALES AS PER LOCATION\n-----------------------------\n");
	femaleComparator();
	fw.write("MALES AS PER LOCATION\n-----------------------------\n");
	maleComparator();
	//CLOSE FILE AFTER ONE OPENS IT
	fw.close();
	String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
	System.out.println("Cur dt=" + timeStamp + "\nProgrammed by ZESHAN SAYED\n");

}

}