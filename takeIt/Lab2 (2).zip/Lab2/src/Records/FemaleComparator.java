package Records;
import java.util.Comparator;

public class FemaleComparator implements Comparator <BankRecords> {

	@Override
	public int compare(BankRecords o1, BankRecords o2) {
		// TODO Auto-generated method stub
		int result = o1.getSex().compareTo(o2.getSex());
				if (result !=0){
					return result;
				}
				else
					result= o1.getMortgage().compareTo(o2.getMortgage());
					if(result !=0){return result;}
					else 
						return o1.getSaveact().compareTo(o2.getSaveact());
						
	}

}
