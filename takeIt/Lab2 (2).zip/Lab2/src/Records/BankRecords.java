package Records;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class BankRecords extends Client{
	//include data types
	//array list object
	//3 methods0
	//objects for handling data
	//static BankRecords[] robjs= new BankRecords[600];
	//static ArrayList<String> aray = new ArrayList<String>();
	protected static BankRecords [] robjs = new BankRecords[600];
//creating multidimensional array list
	List<List<String>> aray = new ArrayList<List<String>>();


	// members
	private String id;
	
	
	private int age;
	private String sex;
	private String region;
	private float income;
	private float income1;
	


	public float getIncome1() {
		return income1;
	}
	public void setIncome1(float income1) {
		this.income1 = income1;
	}
	private String married;
	private String children;
	private String car;
	private String saveact;
	private String currentact;
	private String mortgage;
	private String pep;
;
	// generating getters and setters


	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public float getIncome() {
		return income;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}

	public String getMortgage() {
		return mortgage;
	}
	public void setMortgage(String mortgage) {
		this.mortgage = mortgage;
	}

	
	 public String getMarried() {
		return married;
	}
	public void setMarried(String married) {
		this.married = married;
	}
	public String getChildren() {
		return children;
	}
	public void setChildren(String children) {
		this.children = children;
	}
	public String getCar() {
		return car;
	}
	public void setCar(String car) {
		this.car = car;
	}
	public String getSaveact() {
		return saveact;
	}

	public void setSaveact(String saveact) {
		this.saveact = saveact;
	}
	public String getCurrentact() {
		return currentact;
	}
	public void setCurrentact(String currentact) {
		this.currentact = currentact;
	}
	public String getPep() {
		return pep;
	}
	public void setPep(String pep) {
		this.pep = pep;
	}
	public void setIncome(float f) {
		this.income= f;
	}
	//private void setIncome1(String income) {
		//this.income=income;
		
	//}
	
	
	
	//Main where we call methods	
	//public static void main(String[] args)
	// { 
		// BankRecords br = new BankRecords();
		// br.readData();
		//	String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
//	 }
	
	
	

	
	 //override the 3 methods
	@Override
	public void readData() {
		String line="";//initializing line 
		 
		{
			try(BufferedReader br= new BufferedReader(new FileReader("bank-Detail.csv")))//file calling
					{//Object line;
				while (((line = br.readLine())!=null))	//check if empty
							{
								//split array when comma occurs
								aray.add((List<String>) Arrays.asList(line.split(",")));
							
							}
					}catch(FileNotFoundException e)
					{
						e.printStackTrace();
					}
					catch(IOException e){
						e.printStackTrace();
					}
		}
		processData();
	}
	
	
	public void printData(){
		
		//ID, AGE, SEX, REGION, INCOME, and MORTGAGE print
		System.out.println("ID\t\tAGE\t\tSEX\t\tREGION\t\t\tINCOME\t\t\tMORTGAGE\n");
		
		//create a loop to grab data
		for (int i=0;i<=24;i++)
		{
			String s= String.format("%s\t\t%d\t\t%s\t\t%-10s"+"\t\t%-8.2f\t\t%5s\n",robjs[i].getId(),robjs[i].getAge(),robjs[i].getSex(),robjs[i].getRegion(),robjs[i].getIncome1(),robjs[i].getMortgage());
			System.out.println(s);
		}
	}
	@Override
	
	public void processData() {
		
		int index=0;
		for(List<String> rawData:aray)
		{
			//add values to my array
			robjs[index] = new BankRecords();
			robjs[index].setId(rawData.get(0));
			robjs[index].setAge(Integer.parseInt(rawData.get(1)));
			robjs[index].setSex(rawData.get(2));
			robjs[index].setRegion(rawData.get(3));
			robjs[index].setIncome(Float.parseFloat(rawData.get(4)));
			robjs[index].setMarried(rawData.get(5));
			robjs[index].setChildren(rawData.get(6));
			robjs[index].setCar(rawData.get(7));
			robjs[index].setSaveact(rawData.get(8));
			robjs[index].setCurrentact(rawData.get(9));
			robjs[index].setMortgage(rawData.get(10));
			robjs[index].setPep(rawData.get(11));
		//	System.out.println(robjs[index].getId());
			index++;
		}
		//printData();
	}
	

	

	
	
	
}
