package Records;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Login {
	
	private JFrame mainFrame;
	private JLabel headerLabel;
	private JLabel statusLabel;
	private JPanel controlPanel;
	
	public Login(){
	prepareGUI();
	}
	
	
	public static void main(String[] args){
		Login login=new Login();
		login.showTextField();
		

	}

	

private void showTextField() {
		// TODO Auto-generated method stub
		
	}


private void prepareGUI() {
	// TODO Auto-generated method stub
	
}





}