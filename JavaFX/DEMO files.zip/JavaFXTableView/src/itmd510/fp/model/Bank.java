package itmd510.fp.model;

public class Bank {

	private Integer id; //Primary column of the table
	private String name; //Name of the bank
	private String address; //Address of the bank
	
	//Empty Default constructor
	public Bank() {
	}
	
	//Fully parameterized constructor
	public Bank(Integer id, String name, String address) {
		this.id = id;
		this.name = name;
		this.address = address;
	}

	//Getter / Setter methods for each attribute of the class
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}