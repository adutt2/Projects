package itmd510.fp.controller;

import java.sql.Connection;
import java.sql.ResultSet;

import Connection.DBConnect;
import itmd510.fp.dao.BankDAO;
import itmd510.fp.model.Bank;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;


public class AddBankController   {
	//This is the parent stage
	private Stage dialogStage;
		
	//This is the Text box element in the view for name of bank
	@FXML
	private TextField name;
	//This is the Text box element in the view for address of bank
	@FXML
	private TextField address;
	
	//Method to set the parent stage of the current view
 	public void setDialogStage(Stage dialogStage) {
 		this.dialogStage = dialogStage;
 		
 	}
	
	//Method to save the form to database
	public void save() {
		//Extract the data from the view elements
		String name = this.name.getText();
		String address = this.address.getText();
		//Validate the data
		if(name == null || name.trim().equals("")) {
			return;
		}
		if(address == null || address.trim().equals("")) {
			return;
		}
		//Create the model object
		Bank bank = new Bank();
		//Set the values from the input form
		bank.setName(name);
		bank.setAddress(address);
		//Create a DAO instance of the model
		BankDAO b = new BankDAO();
		//Use the DAO to persist the model to database
		b.create(bank);
		//Close the stage after saving
		//close();
	}
	
	//Method to cancel the action
	public void cancel() {
		close();
	}
	
	//This is required as stage.close() in the program will not trigger any events.
	//To have callback listeners on the close event, we trigger the external close event
	private void close() {
		dialogStage.fireEvent(new WindowEvent(dialogStage,WindowEvent.WINDOW_CLOSE_REQUEST));
	}
	 
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void open(ActionEvent event) throws Exception {  
	    
	         @SuppressWarnings({ "rawtypes" })
	    	
	         //TABLE VIEW AND DATA

	    	TableView tableview = new TableView();
	    	ObservableList<ObservableList> data;
	
	    	//CONNECTION DATABASE
	    	  Connection c ;
	          data = FXCollections.observableArrayList();
	          try{
	            c = DBConnect.connect();
	            //SQL FOR SELECTING ALL OF CUSTOMER
	            String SQL = "SELECT * from sample_bank";
	            //ResultSet
	            ResultSet rs = c.createStatement().executeQuery(SQL);

	            /**********************************
	             * TABLE COLUMN ADDED DYNAMICALLY *
	             **********************************/
	            for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){
	                //We are using non property style for making dynamic table
	                final int j = i;                
	                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
	                col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){                    
	                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {                                                                                              
	                        return new SimpleStringProperty(param.getValue().get(j).toString());                        
	                    }                    
	                });
	               
	                tableview.getColumns().addAll(col); 
	                System.out.println("Column ["+i+"] ");
	            }

	            /********************************
	             * Data added to ObservableList *
	             ********************************/
	            while(rs.next()){
	                //Iterate Row
	                ObservableList<String> row = FXCollections.observableArrayList();
	                for(int i=1 ; i<=rs.getMetaData().getColumnCount(); i++){
	                    //Iterate Column
	                    row.add(rs.getString(i));
	                }
	                System.out.println("Row [1] added "+row );
	                data.add(row);
	            }

	            //FINALLY ADD TO TableView
	            tableview.setItems(data);
	          }catch(Exception e){
	              e.printStackTrace();
	              System.out.println("Error on Building Data");             
	          }
	       
	        //Create Main Scene (pop up)
	        tableview.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
	        Scene scene = new Scene(tableview);        
	        Stage stage = new Stage();
	        stage.setWidth(500);
	        stage.setScene(scene);
	        stage.show();
  }
}