package itmd510.fp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import itmd510.fp.model.Bank;

public class BankDAO {
	
	//Connection object
	private Connection connection;
	//Database connection parameters
    private String url = "jdbc:mysql://www.papademas.net:3306/dbfp";
    private String username = "fpuser";
    private String password = "510";

    //Method to save a bank model to database
	public Bank create(Bank bank) {
		//Get a connection
		try {
            connection = DriverManager.getConnection(url, username, password);
        } catch(SQLException e) {
            System.out.println("Error creating connection to database: " + e);
            System.exit(-1);
        }
		//Query to insert a record to the bank table
		String query = "INSERT INTO sample_bank (name, address) VALUES (?, ?) ;";
		//Use prepared statements to avoid SQL injection attacks
		try(PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)){
			//Set the parameters to the query
            statement.setString(1, bank.getName());
            statement.setString(2, bank.getAddress());
            //Execute the insert
            statement.executeUpdate();
            //To get the primary key (id) of the newly inserted record
            ResultSet resultSet = statement.getGeneratedKeys();
            if(resultSet.next()) {
            	//Set the id field of the database to the model
            	bank.setId(resultSet.getInt(1));
            }
        } catch(SQLException e){
        	bank = null;
            System.out.println("Error Creating Bank: " + e);
        }
		//Close the connection to the database - Very important!!!
		try {
            connection.close();
            connection = null;
        } catch(SQLException e) {
            System.out.println("Error closing connection: " + e);
        }
		//Return the bank object that was inserted with the id field set.
		return bank;
	}
}