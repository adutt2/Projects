package Connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * 
 * @author me
 */

public class DBConnect { 

	//Connection object
	private static Connection connection;
	//Database connection parameters
    private static String url = "jdbc:mysql://www.papademas.net:3306/dbfp";
    private static String username = "fpuser";
    private static String password = "510";

    public static Connection connect() throws SQLException{
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        }catch(ClassNotFoundException cnfe){
            System.err.println("Error: "+cnfe.getMessage());
        }catch(InstantiationException ie){
            System.err.println("Error: "+ie.getMessage());
        }catch(IllegalAccessException iae){
            System.err.println("Error: "+iae.getMessage());
        }

        connection = DriverManager.getConnection(url,username,password);
        return connection;
    }
    public static Connection getConnection() throws SQLException, ClassNotFoundException{
        if(connection !=null && !connection.isClosed())
            return connection;
        connect();
        return connection;

    }
}