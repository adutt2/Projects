package application;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class menuController extends Application {

	@FXML private Menu File;
	@FXML private MenuItem Close;
	
	 /**
	    * Start of JavaFX application demonstrating menu support.
	    * 
	    * @param stage Primary stage.
	    * @throws IOException 
	    */
	 
	   @Override
	   public void start(Stage stage) throws IOException
	   {
		   FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/main.fxml"));
           AnchorPane root = (AnchorPane) loader.load();
           stage.setTitle("SceneBuilder Menu");
          
           Scene scene = new Scene(root);
           stage.setScene(scene);
           stage.show();
           
	   }

	   @FXML
	   void closeOut() {
	       //body
		   System.out.print("Close item event action");
	   }
      
	   
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
