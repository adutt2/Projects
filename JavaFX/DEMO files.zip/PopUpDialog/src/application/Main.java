package application;
	
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Main extends Application {
	
	    Button btnYes, btnNo;
	    FlowPane pane1, pane2;
	    Scene scene1, scene2;
	    Stage thestage, stage;
	    
	    public void ButtonClicked(ActionEvent e)
		{
			 if (e.getSource()==btnYes)
				 System.out.println("Yes clicked");
				 //stage.close();
		         
		      else
		         // stage.showAndWait();
		       	System.out.println("No was clicked");
		        	
			  /* swap scenes as option
			  * if (e.getSource()==btnscene1)
	            thestage.setScene(scene2);
	            else
	            thestage.setScene(scene1); */
	    }
	    
	@Override
	public void start(Stage primaryStage) {
		
        	 stage = new Stage();
             stage.setTitle("Delete Client?");
		     btnYes=new Button("Yes");
		     btnNo=new Button("No");
		     btnYes.setOnAction(e-> ButtonClicked(e));
		     btnNo.setOnAction(e-> ButtonClicked(e));
		     HBox hbox = new HBox(8); //build hbox for spacing (8 spaces between controls)
		     hbox.getChildren().addAll(btnYes, btnNo);

		     //make 2 Panes
		     pane1=new FlowPane(); 
		     pane2=new FlowPane();
		     pane1.setVgap(10);
		     pane2.setVgap(10);
		     //set background color of each desired Pane
		     pane1.setStyle("-fx-background-color: tan;-fx-padding: 10px;");
		     pane2.setStyle("-fx-background-color: red;-fx-padding: 10px;");
		        
		     //add everything to panes
		     pane1.setAlignment(Pos.CENTER);
		     pane1.getChildren().addAll(hbox);  

	 	     //make 2 scenes from 2 panes if nec.
		     scene1 = new Scene(pane1, 200, 100);
		     //scene2 = new Scene(pane2, 200, 100);
		         
		     stage.setScene(scene1);
		     stage.initModality(Modality.APPLICATION_MODAL);
		     stage.sizeToScene(); 
		     stage.show(); 
 	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
