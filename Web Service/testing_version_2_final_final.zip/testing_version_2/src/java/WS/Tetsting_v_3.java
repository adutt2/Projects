/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import Beans.ServiceBean;
import Models.CommentsModel;
import Models.CustomerModel;
import Models.EmployeeModel;
import Models.ExpenseModel;
import Models.LocationModel;
import Models.OrderModel;
import Models.PaymentModel;
import Models.PricingModel;
import Models.TransactionModel;
import Models.TrucksModel;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Zeshan
 */
@WebService(serviceName = "Tetsting_v_3")
public class Tetsting_v_3 {

    @EJB
    private ServiceBean ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "getLocations")
    public List<LocationModel> getLocations(@WebParam(name = "loc_id") String loc_id, @WebParam(name = "postalcode") String postalcode) {
        return ejbRef.getLocations(loc_id, postalcode);
    }

    @WebMethod(operationName = "getCustomer")
    public List<CustomerModel> getCustomer(@WebParam(name = "cust_id") String cust_id, @WebParam(name = "cust_city") String cust_city) {
        return ejbRef.getCustomer(cust_id, cust_city);
    }

    @WebMethod(operationName = "getEmployee")
    public List<EmployeeModel> getEmployee(@WebParam(name = "exp_id") String exp_id) {
        return ejbRef.getEmployee(exp_id);
    }

    @WebMethod(operationName = "getExpenses")
    public List<ExpenseModel> getExpenses(@WebParam(name = "expn_id") String expn_id) {
        return ejbRef.getExpenses(expn_id);
    }

    @WebMethod(operationName = "getComment")
    public List<CommentsModel> getComment() {
        return ejbRef.getComment();
    }

    @WebMethod(operationName = "getTrucks")
    public List<TrucksModel> getTrucks(@WebParam(name = "truck_id") String truck_id) {
        return ejbRef.getTrucks(truck_id);
    }

    @WebMethod(operationName = "getOrder")
    public List<OrderModel> getOrder(@WebParam(name = "order_id") String order_id) {
        return ejbRef.getOrder(order_id);
    }

    @WebMethod(operationName = "getPricing")
    public List<PricingModel> getPricing() {
        return ejbRef.getPricing();
    }

    @WebMethod(operationName = "getPayment")
    public List<PaymentModel> getPayment() {
        return ejbRef.getPayment();
    }

    @WebMethod(operationName = "getTransaction")
    public List<TransactionModel> getTransaction() {
        return ejbRef.getTransaction();
    }
    
}
