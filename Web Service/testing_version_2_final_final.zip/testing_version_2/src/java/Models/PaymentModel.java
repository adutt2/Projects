/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author aniru
 */
public class PaymentModel {
    
    private String paymentID;
    private String orderID;
    private String paymentMethodID;
    private String paymentAmount;
    private String paymentDate;
    private String checkNumber;
    private String creditCard;
    private String creditCardNumber;
    private String cardholdersName;
    private String creditCardExpDate;
    private String creditCardAuthorizationNumber;

    public String getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getPaymentMethodID() {
        return paymentMethodID;
    }

    public void setPaymentMethodID(String paymentMethodID) {
        this.paymentMethodID = paymentMethodID;
    }

    public String getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(String paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getCheckNumber() {
        return checkNumber;
    }

    public void setCheckNumber(String checkNumber) {
        this.checkNumber = checkNumber;
    }

    public String getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(String creditCard) {
        this.creditCard = creditCard;
    }

    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(String creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public String getCardholdersName() {
        return cardholdersName;
    }

    public void setCardholdersName(String cardholdersName) {
        this.cardholdersName = cardholdersName;
    }

    public String getCreditCardExpDate() {
        return creditCardExpDate;
    }

    public void setCreditCardExpDate(String creditCardExpDate) {
        this.creditCardExpDate = creditCardExpDate;
    }

    public String getCreditCardAuthorizationNumber() {
        return creditCardAuthorizationNumber;
    }

    public void setCreditCardAuthorizationNumber(String creditCardAuthorizationNumber) {
        this.creditCardAuthorizationNumber = creditCardAuthorizationNumber;
    }
    
    
    public String toString() {
		return "paymentID=" + this.paymentID + " paymentMethodID=" + this.paymentMethodID + " creditCard=" + this.creditCard;
    }
    
    
}
