
import Models.LocationModel;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


/**
 *
 * @author Zeshan
 */
public class LocationParser extends DefaultHandler {
    LocationModel lm = null;
    private List<LocationModel> lmst= new ArrayList<>();
    String temp = null;
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
		switch (qName) {
		case "location":
			lm = new LocationModel();
			lm.setLocationID(atts.getValue("locationID"));
			break;
		}
    }
    public void characters(char[] ch, int start, int length) throws SAXException {
		temp = String.copyValueOf(ch, start, length).trim();
	}
    
    
	public void endElement(String uri, String localName, String qName) throws SAXException {
		
		switch (qName) {
		case "location":
			lmst.add(lm);
			break;
		case "locName":
			lm.setLocName(temp);
			break;
		case "locationCode":
			lm.setLocationCode(temp);
			break;
		case "IsAuction":
			lm.setIsAuction(temp);
			break;
		case "customerID":
			lm.setCustomerID(temp);
			break;
		case "addressline1":
			lm.setAddressStreet1(temp);
			break;
		case "addressline2":
			lm.setAddressStreet2(temp);
			break;
		case "city":
			lm.setCity(temp);
			break;
		case "state":
			lm.setState(temp);
			break;
		case "postalCode":
			lm.setPostalCode(temp);
			break;
		case "region":
			lm.setRegion(temp);
			break;
		case "LocationConactName":
			lm.setLocation_contact_name(temp);
			break;
		case "locPhone":
			lm.setLocPhone(temp);
			break;
		case "locFaxNumber":
			lm.setLocFaxNumber(temp);
			break;
		case "locEmail":
			lm.setLocEmail(temp);
			break;
		}
	}
	public List<LocationModel> getClist() {
		return lmst;
	}
    
}
