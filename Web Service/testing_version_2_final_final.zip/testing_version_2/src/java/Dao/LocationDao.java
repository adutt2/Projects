/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;
import Connection.DBConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author Zeshan
 */
public class LocationDao {
    
    DBConnect conn = new DBConnect ();
	private Statement statement = null;
        private PreparedStatement stmt=null;
    
    public ResultSet getLocations(String loc_id,String postalcode) throws Exception {
		ResultSet loc = null;
		try {
                        System.out.println("Loging dao mai aaya");
			statement = conn.getConnection().createStatement();
			String qr = "select * from location where locationid='"+loc_id+"' and postalcode='"+postalcode+"'";
			loc = statement.executeQuery(qr);
                        System.out.print(loc);
			//statement.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return loc;
		
	} 
    
  
    
    
    
}
