/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Connection.DBConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Zeshan
 */
public class CommentsDao {
    
    
    DBConnect conn = new DBConnect ();
	private Statement statement = null;
        private final PreparedStatement stmt=null;
    
    public ResultSet getComments() throws Exception {
		ResultSet comm = null;
		try {
                        System.out.println("Comment dao mai aaya");
			statement = DBConnect.getConnection().createStatement();
			String qr = "Select COMMENTID,COMMENTTIME,COMMENTS,COMMENTTYPE \n" +
"from comments";
			comm = statement.executeQuery(qr);
                      //  System.out.print(c1.getString(qr));
			//statement.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return comm;
		
	} 
    
   
    
}
