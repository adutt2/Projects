Backend:
-We have used JAVA as backend. We created a session bean class with all the methods for our web service. We then created a web service from the session bean.
-Each method returned an arraylist of model class objects.
-We also created a DBconnect file which has our data base connection parameters.
-Model files has the data methods to initialize and retreive data variables which store values retreived from Database.
-Dao class files has sql queries for our web services.

Frontend:
-We implemented our front end with JSP. 
-Our index.jsp page has a login form which will users with correct username and password.
-The Welcome page(error.jsp) has links to webpages implementing few of our web services.
-The more services hyperlink on the welcome page connects to webpage with rest of our web services.
-Finally, result of our web services are displayed in a table.

Database:
-We have used MySQL Server as our database client and Wampserver to host our database.	