/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Connection.DBConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Zeshan
 */
public class PaymentDao {
    
    DBConnect conn = new DBConnect ();
	private Statement statement = null;
        private PreparedStatement stmt=null;
    
    public ResultSet getPayment() throws Exception {
		ResultSet payment = null;
		try {
                        System.out.println("Loging dao mai aaya");
			statement = conn.getConnection().createStatement();
			String qr = "select * from payments";
			payment = statement.executeQuery(qr);
                        System.out.print(payment);
			//statement.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return payment;
		
	} 
    
    
}
