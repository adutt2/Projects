/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Connection.DBConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Zeshan
 */
public class ExpenseDao {
    
    DBConnect conn = new DBConnect ();
	private Statement statement = null;
        private PreparedStatement stmt=null;
    
    public ResultSet getExpenses( String expn_id) throws Exception {
		ResultSet exp = null;
		try {
                        System.out.println("Expense dao mai aaya");
			statement = conn.getConnection().createStatement();
			String qr = "select * from expenses where expenseid='"+expn_id+"'";
			exp = statement.executeQuery(qr);
                        System.out.print(exp);
			//statement.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return exp;
		
	} 

    
}
