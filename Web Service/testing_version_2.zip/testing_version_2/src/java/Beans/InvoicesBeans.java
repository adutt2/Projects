/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.lang.reflect.InvocationTargetException;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.jws.WebParam;
/**

/**
 *
 * @author Zeshan
 */
@Stateless
public class InvoicesBeans {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
     public List Get_Invoices(@WebParam(name = "Pay_Id") String Pay_Id,@WebParam(name = "Cust_Id") String Cust_Id) throws ClassNotFoundException, InvocationTargetException {
        //TODO write your implementation code here:
        List list = new ArrayList();
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        String JDBC_URL = "jdbc:mysql://localhost:3307/final_database_v_1";
        String USR = "root";
        String PASS = "";
        // ArrayList <String> a1 = new ArrayList<String>();
        try {
            Class.forName(JDBC_DRIVER);
            Connection conn = DriverManager.getConnection(JDBC_URL, USR, PASS);
            try (Statement statement = conn.createStatement()) {
                ResultSet rs = statement.executeQuery(" SELECT c.cust_business_name,i.inv_id,e.emp_fname,e.emp_email from employee e, invoice i, customer c WHERE i.inv_cust_id=c.cust_id and i.inv_emp_id=e.emp_id and i.inv_pay_id='"+Pay_Id+"' and c.cust_id='"+Cust_Id+"' ;");
        while (rs.next()) {                            
                 list.add(rs.getString(1));
                 list.add(rs.getInt(2));
                 list.add(rs.getString(3));
                 list.add(rs.getString(4));
         

            
                conn.close();
            }
            System.out.println("Customer searching in progress.......");
            //close connection
            //           System.out.println(BusinessName);
        }

    }
    catch(SQLException e ){
		System.out.print(e.getMessage());

    }
    catch(ClassNotFoundException e){
                                
                           }
       
    return list ;

}
}
