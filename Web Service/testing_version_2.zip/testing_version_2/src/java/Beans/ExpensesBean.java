/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.lang.reflect.InvocationTargetException;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.jws.WebParam;
/**
 *
 * @author Zeshan
 */
@Stateless
public class ExpensesBean {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
     public List Get_Eexpenses(@WebParam(name = "Exp_purpose") String Exp_purpose) throws ClassNotFoundException, InvocationTargetException {
        //TODO write your implementation code here:
        List list = new ArrayList();
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        String JDBC_URL = "jdbc:mysql://localhost:3307/final_database_v_1";
        String USR = "root";
        String PASS = "";
        // ArrayList <String> a1 = new ArrayList<String>();
        try {
            Class.forName(JDBC_DRIVER);
            Connection conn = DriverManager.getConnection(JDBC_URL, USR, PASS);
            try (Statement statement = conn.createStatement()) {
                ResultSet rs = statement.executeQuery(" select e.emp_fname,e.emp_lname ,e.emp_id,exp.exp_amount_spent from employee e,expense exp where e.emp_id=exp.exp_emp_id and exp.exp_purpose='" +Exp_purpose+"';");
        while (rs.next()) {                            
                 list.add(rs.getString(1));
                 list.add(rs.getString(2));
                 list.add(rs.getInt(3));
                  list.add(rs.getInt(4));  
            
                conn.close();
            }
            System.out.println("Customer searching in progress.......");
            //close connection
            //           System.out.println(BusinessName);
        }

    }
    catch(SQLException e ){
		System.out.print(e.getMessage());

    }
    catch(ClassNotFoundException e){
                                
                           }
       
    return list ;

}
}
