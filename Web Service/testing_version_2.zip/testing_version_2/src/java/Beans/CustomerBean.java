/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.jws.WebParam;

/**
 *
 * @author Zeshan
 */
@Stateless
public class CustomerBean {

    // DBConnect conn = new DBConnect ();
    public List Get_Customer(@WebParam(name = "Customer_State") String Customer_State) throws ClassNotFoundException, InvocationTargetException {
        //TODO write your implementation code here:
        List list = new ArrayList();
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        String JDBC_URL = "jdbc:mysql://localhost:3307/final_database_v_1";
        String USR = "root";
        String PASS = "";
        // ArrayList <String> a1 = new ArrayList<String>();
        try {
            Class.forName(JDBC_DRIVER);
            Connection conn = DriverManager.getConnection(JDBC_URL, USR, PASS);
            try (Statement statement = conn.createStatement()) {
                ResultSet rs = statement.executeQuery("SELECT  cust_id,cust_business_name,cust_city from customer where cust_state='"+Customer_State+"';");
        while (rs.next()) {
                 list.add(rs.getString(1));
                 list.add(rs.getString(2));
                  list.add(rs.getString(3));
                conn.close();
            }
            System.out.println("Customer searching in progress.......");
            //close connection
            //           System.out.println(BusinessName);
        }

    }
    catch(SQLException e

    
        ){
		System.out.print(e.getMessage());

    }
    catch(ClassNotFoundException e

    
 
    ){
                                
                           }
       
        
                   
        
				
    
             
        
                   
        
				
    
      
    return list ;

}
}
