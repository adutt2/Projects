/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import Beans.OrderBeans;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Zeshan
 */
@WebService(serviceName = "Order")
public class Order {

    @EJB
    private OrderBeans ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "Get_Order")
    public List Get_Order(@WebParam(name = "OrderId") String OrderId) throws ClassNotFoundException, InvocationTargetException {
        return ejbRef.Get_Order(OrderId);
    }
    
}
