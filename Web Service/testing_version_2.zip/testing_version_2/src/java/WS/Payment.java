/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Zeshan
 */
@WebService(serviceName = "Payment")
public class Payment {

    @EJB
    private Beans.Payment ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "Get_Payment")
    public List Get_Payment(@WebParam(name = "Paymentid") String Paymentid) throws ClassNotFoundException, InvocationTargetException {
        return ejbRef.Get_Payment(Paymentid);
    }
    
}
