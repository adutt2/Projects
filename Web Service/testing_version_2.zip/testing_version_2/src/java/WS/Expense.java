/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import Beans.ExpensesBean;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Zeshan
 */
@WebService(serviceName = "Expense")
public class Expense {

    @EJB
    private ExpensesBean ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "Get_Eexpenses")
    public List Get_Eexpenses(@WebParam(name = "Exp_purpose") String Exp_purpose) throws ClassNotFoundException, InvocationTargetException {
        return ejbRef.Get_Eexpenses(Exp_purpose);
    }
    
}
