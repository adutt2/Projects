/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import Beans.InvoicesBeans;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Zeshan
 */
@WebService(serviceName = "Invoices")
public class Invoices {

    @EJB
    private InvoicesBeans ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "Get_Invoices")
    public List Get_Invoices(@WebParam(name = "Pay_Id") String Pay_Id, @WebParam(name = "Cust_Id") String Cust_Id) throws ClassNotFoundException, InvocationTargetException {
        return ejbRef.Get_Invoices(Pay_Id, Cust_Id);
    }
    
}
