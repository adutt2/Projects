/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import Beans.EmployeesBean;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Zeshan
 */
@WebService(serviceName = "Employee")
public class Employee {

    @EJB
    private EmployeesBean ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "Get_Employee")
    public List Get_Employee(@WebParam(name = "Emp_job_title") String Emp_job_title) throws ClassNotFoundException, InvocationTargetException {
        return ejbRef.Get_Employee(Emp_job_title);
    }
    
}
