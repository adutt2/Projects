/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.lang.reflect.InvocationTargetException;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.jws.WebParam;

/**
 *
 * @author Zeshan
 */
@Stateless
public class LocationBeans {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    public List Get_Location(@WebParam(name = "Cust_id") String Cust_id, @WebParam(name = "Loc_IsAuction") String Loc_IsAuction) throws ClassNotFoundException, InvocationTargetException {
        //TODO write your implementation code here:
        List list = new ArrayList();
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        String JDBC_URL = "jdbc:mysql://localhost:3307/final_database_v_1";
        String USR = "root";
        String PASS = "";
        // ArrayList <String> a1 = new ArrayList<String>();
        try {
            Class.forName(JDBC_DRIVER);
            Connection conn = DriverManager.getConnection(JDBC_URL, USR, PASS);
            try (Statement statement = conn.createStatement()) {
                ResultSet rs = statement.executeQuery(" select l.loc_contact_name, l.loc_phone,p.prc_loc_from,p.prc_loc_to,p.prc_price\n" +
"from location l,customer c,pricing p \n" +
"WHERE l.loc_cust_id= c.cust_id AND p.prc_cust_id=c.cust_id AND c.cust_id='"+Cust_id+"' AND l.loc_isauction='"+Loc_IsAuction+"';");
        while (rs.next()) {                            
                 list.add(rs.getString(1));
                 list.add(rs.getInt(2));
                 list.add(rs.getString(3));
                   list.add(rs.getString(4));
                     list.add(rs.getInt(5));
         

            
                conn.close();
            }
            System.out.println("Customer searching in progress.......");
            //close connection
            //           System.out.println(BusinessName);
        }

    }
    catch(SQLException e ){
		System.out.print(e.getMessage());

    }
    catch(ClassNotFoundException e){
                                
                           }
       
    return list ;

}
}
