/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import Beans.TransactionsBean;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Zeshan
 */
@WebService(serviceName = "Transaction")
public class Transaction {

    @EJB
    private TransactionsBean ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "Get_transactions")
    public List Get_transactions(@WebParam(name = "Prc_loc_from") String Prc_loc_from) throws ClassNotFoundException, InvocationTargetException {
        return ejbRef.Get_transactions(Prc_loc_from);
    }
    
}
