/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import Beans.CustomerBean;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Zeshan
 */
@WebService(serviceName = "Customer")
public class Customer {

    @EJB
    private CustomerBean ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "Get_Customer")
    public List Get_Customer(@WebParam(name = "Customer_State") String Customer_State) throws ClassNotFoundException, InvocationTargetException {
        return ejbRef.Get_Customer(Customer_State);
    }
    
}
