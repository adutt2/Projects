/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import Beans.LocationBeans;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Zeshan
 */
@WebService(serviceName = "Location")
public class Location {

    @EJB
    private LocationBeans ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "Get_Location")
    public List Get_Location(@WebParam(name = "Cust_id") String Cust_id, @WebParam(name = "Loc_IsAuction") String Loc_IsAuction) throws ClassNotFoundException, InvocationTargetException {
        return ejbRef.Get_Location(Cust_id, Loc_IsAuction);
    }
    
}
