/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import Dao.ExpenseDao;
import Models.ExpenseModel;
import java.lang.reflect.InvocationTargetException;
import javax.ejb.Stateless;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebParam;
/**
 *
 * @author Zeshan
 */
@Stateless
public class ExpensesBean {

    // Add business logic below. (Right-click in editor and choose
   ExpenseDao ds=new ExpenseDao();
 
    public List<ExpenseModel> getExpenses() {
    	ExpenseModel em=null;
		List<ExpenseModel> llist=new ArrayList<>();
		try {
		ResultSet sr= ds.getExpenses();
			while(sr.next()){
			em=new ExpenseModel();	
			em.setExpenseID(sr.getString("expenseID"));
                        em.setEmployeeID(sr.getString("employeeID"));
                        em.setExpenseType(sr.getString("expenseType"));
                        em.setPurposeofExpense(sr.getString("purposeofExpense"));
                        em.setAmountSpent(sr.getString("amountSpent"));
                        em.setDescription(sr.getString("description"));
                        em.setDatePurchased(sr.getString("datePurchased"));
                        em.setDateSubmitted(sr.getString("dateSubmitted"));
                        em.setAdvanceAmount(sr.getString("advanceAmount"));
                        em.setPaymentMethod(sr.getString("paymentMethod"));
                        			llist.add(em);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return llist;
    }
    
}
