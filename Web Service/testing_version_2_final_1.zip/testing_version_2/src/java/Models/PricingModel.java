/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author aniru
 */
public class PricingModel {
    
    private String priceID;
    private String locationIDFrom;
    private String locationIDTO;
    private String price;
    private String locationCodeFrom;
    private String locationCodeTo;
    private String locationNameFrom;
    private String locationNameTo;
    private String customerID;

    public String getPriceID() {
        return priceID;
    }

    public void setPriceID(String priceID) {
        this.priceID = priceID;
    }

    public String getLocationIDFrom() {
        return locationIDFrom;
    }

    public void setLocationIDFrom(String locationIDFrom) {
        this.locationIDFrom = locationIDFrom;
    }

    public String getLocationIDTO() {
        return locationIDTO;
    }

    public void setLocationIDTO(String locationIDTO) {
        this.locationIDTO = locationIDTO;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getLocationCodeFrom() {
        return locationCodeFrom;
    }

    public void setLocationCodeFrom(String locationCodeFrom) {
        this.locationCodeFrom = locationCodeFrom;
    }

    public String getLocationCodeTo() {
        return locationCodeTo;
    }

    public void setLocationCodeTo(String locationCodeTo) {
        this.locationCodeTo = locationCodeTo;
    }

    public String getLocationNameFrom() {
        return locationNameFrom;
    }

    public void setLocationNameFrom(String locationNameFrom) {
        this.locationNameFrom = locationNameFrom;
    }

    public String getLocationNameTo() {
        return locationNameTo;
    }

    public void setLocationNameTo(String locationNameTo) {
        this.locationNameTo = locationNameTo;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }
    

    public String toString() {
		return "priceID=" + this.priceID + " price=" + this.price + " customerID=" + this.customerID;
    }
}
