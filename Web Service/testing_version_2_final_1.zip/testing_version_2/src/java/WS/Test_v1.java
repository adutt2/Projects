/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import Beans.ServiceBean;
import Models.CommentsModel;
import Models.CustomerModel;
import Models.EmployeeModel;
import Models.ExpenseModel;
import Models.LocationModel;
import Models.OrderModel;
import Models.PaymentModel;
import Models.PricingModel;
import Models.TransactionModel;
import Models.TrucksModel;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Zeshan
 */
@WebService(serviceName = "Test_v1")
public class Test_v1 {

    @EJB
    private ServiceBean ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "getLocations")
    public List<LocationModel> getLocations() {
        return ejbRef.getLocations();
    }

    @WebMethod(operationName = "getCustomer")
    public List<CustomerModel> getCustomer(@WebParam(name = "cust_id") String cust_id) {
        return ejbRef.getCustomer(cust_id);
    }

    @WebMethod(operationName = "getEmployee")
    public List<EmployeeModel> getEmployee() {
        return ejbRef.getEmployee();
    }

    @WebMethod(operationName = "getExpenses")
    public List<ExpenseModel> getExpenses() {
        return ejbRef.getExpenses();
    }

    @WebMethod(operationName = "getComment")
    public List<CommentsModel> getComment() {
        return ejbRef.getComment();
    }

    @WebMethod(operationName = "getTrucks")
    public List<TrucksModel> getTrucks() {
        return ejbRef.getTrucks();
    }

    @WebMethod(operationName = "getOrder")
    public List<OrderModel> getOrder() {
        return ejbRef.getOrder();
    }

    @WebMethod(operationName = "getPricing")
    public List<PricingModel> getPricing() {
        return ejbRef.getPricing();
    }

    @WebMethod(operationName = "getPayment")
    public List<PaymentModel> getPayment() {
        return ejbRef.getPayment();
    }

    @WebMethod(operationName = "getTransaction")
    public List<TransactionModel> getTransaction() {
        return ejbRef.getTransaction();
    }
    
}
