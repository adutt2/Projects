The Sayed-Zeshan-week-05.pdf contains screenshots and top 10 words
The WordCount.java contains java code for word count for all *-sotu.files.
The WordCount2.java contains java code for word count for all *-sotu.files.
The WordCount3.java contains java code for word count of words occured more than 4 times for all *-sotu.files.
All the data was saved in a file called sotu and executed with java file.
