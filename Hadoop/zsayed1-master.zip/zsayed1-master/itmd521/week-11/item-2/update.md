sqoop commad initiated and job is complete.
also the command hadoop fs -cat widgets/part-m-00000 shows only first value from the database so instead use :hadoop fs -cat widgets/part-m-0000*

![image](https://cloud.githubusercontent.com/assets/25266333/24731254/7b3a6e5a-1a2e-11e7-8ab3-3f613616f392.png)

