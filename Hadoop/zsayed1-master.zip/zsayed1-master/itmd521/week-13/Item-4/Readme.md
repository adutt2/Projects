
**Hive**

Step 1: Created tables in hive with the required datatypes and then import command
Step 2: I directly imported the file from the sqoop into hive table'
Step 3: Then we write same sql quiery with in hive and we get follwing results;
![image](https://cloud.githubusercontent.com/assets/25266333/25561714/8e76f206-2d37-11e7-9460-d1cf0d04c2bd.png)


Query on large data by day:

select p.day, p.m, max(p.link), max(p.c) as max from ((select date(umonth) as day, month(umonth) as m, count(URL) as c, URL as link from logs1 where quality=200 and URL NOT LIKE 'index.%' GROUP BY date(umonth), URL order by day, m) p) group by p.day, p.m order by p.day,p.m;

![large day](https://cloud.githubusercontent.com/assets/25266333/25561649/726d694c-2d36-11e7-8579-c75c9217a201.PNG)



Query on large by month:

select p.day, p.m, max(p.link), max(p.c) as max from ((select (umonth) as day, year*(umonth) as m, count(URL) as c, URL as link from logs1 where quality=200 and URL NOT LIKE 'index.%' GROUP BY date(umonth), URL order by day, m) p) group by p.day, p.m order by p.day,p.m;

![per month](https://cloud.githubusercontent.com/assets/25266333/25561677/12900a24-2d37-11e7-856e-c9e7b79f9828.PNG)

Query on small by day:

select p.day, p.m, max(p.link), max(p.c) as max from ((select date(umonth) as day, month(umonth) as m, count(URL) as c, URL as link from logs2 where quality=200 and URL NOT LIKE 'index.%' GROUP BY date(umonth), URL order by day, m) p) group by p.day, p.m order by p.day,p.m;

Query on small by Month:

select p.day, p.m, max(p.link), max(p.c) as max from ((select date(umonth) as day, year(umonth) as m, count(URL) as c, URL as link from logs2 where quality=200 and URL NOT LIKE 'index.%' GROUP BY date(umonth), URL order by day, m) p) group by p.day, p.m order by p.day,p.m;



