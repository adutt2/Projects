**SQOOP**
We imported the database into the database using the following command:


![image](https://cloud.githubusercontent.com/assets/25266333/25561714/8e76f206-2d37-11e7-9460-d1cf0d04c2bd.png)

Then I typed the code gen code which formed a file called small.java and large,java respectively.

Then instead of using maven I created jar file and then started the job with the required job code.

