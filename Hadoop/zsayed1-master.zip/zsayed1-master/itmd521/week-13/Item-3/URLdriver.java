import java.io.IOException;
import java.util.*;
import com.cloudera.sqoop.lib.RecordParser.ParseError;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.util.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
public class URLdriver extends Configured implements Tool {
public int run(String [] args) throws Exception {
    Job job = new Job(getConf());

    job.setJarByClass(URLdriver.class);

    job.setMapperClass(URLMapper.class);
    job.setReducerClass(URLReducer.class);

    FileInputFormat.addInputPath(job, new Path("small"));
    FileOutputFormat.setOutputPath(job, new Path("MaxURL"));

    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(Text.class);

    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(Text.class);

    job.setNumReduceTasks(1);

    if (!job.waitForCompletion(true)) {
      return 1; // error.
    }

    return 0;
  }

  public static void main(String [] args) throws Exception {
    int ret = ToolRunner.run(new URLdriver(), args);
    System.exit(ret);
  }
}
