import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;
import com.cloudera.sqoop.lib.RecordParser.ParseError;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.util.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
public class URLMapper
      extends Mapper<LongWritable, Text, Text, Text> {

    private small month = null;
    private small URL = null;
    public void map(LongWritable k, Text v, Context context)throws IOException, InterruptedException {
      
    	 try {
    	        URL.parse(v); // Auto-generated: parse all fields from text.
    	      } catch (ParseError pe) {
    	        // Got a malformed record. Ignore it.
    	        return;
    	      }
         String url = URL.get_URL().toString();
         String Month = URL.get_month().toString();
        context.write(new Text(Month), new Text(url));
      
    }
  }

