***Step 1:***First I created a java file which i parsed with the help of spilt by experiencing inefficiency by substring method used in first item.

***Step 2:***Then I imported the java file into vagrant and then JAVAC and JAVA. Once inserted in to .csv file, we then import this csv file in to mysql table.Before inserting, we log mysql with adding **--local-infile** command with mysql -u root -p. Then we create a database with **data types** as we require to optimize the query.

***Step 3:***Then we loaded the **.csv** file from vagrant_data to the table.

***Step 4:***Now we execute query according to our requirement.

Query on large by day:

select p.day, p.m, max(p.link), max(p.c) as max from ((select date(umonth) as day, month(umonth) as m, count(URL) as c, URL as link from logs1 where quality=200 and URL  NOT LIKE 'index.%' GROUP BY date(umonth), URL order by day, m) p) group by p.day, p.m order by p.day,p.m;

Query on large by month:

select p.day, p.m, max(p.link), max(p.c) as max from ((select (umonth) as day, **year***(umonth) as m, count(URL) as c, URL as link from logs1 where quality=200 and URL  NOT LIKE 'index.%' GROUP BY date(umonth), URL order by day, m) p) group by p.day, p.m order by p.day,p.m;


Query on small by day:

select p.day, p.m, max(p.link), max(p.c) as max from ((select date(umonth) as day, month(umonth) as m, count(URL) as c, URL as link from logs2 where quality=200 and URL  NOT LIKE 'index.%' GROUP BY date(umonth), URL order by day, m) p) group by p.day, p.m order by p.day,p.m;

Query on small by Month:

select p.day, p.m, max(p.link), max(p.c) as max from ((select date(umonth) as day, **year**(umonth) as m, count(URL) as c, URL as link from logs2 where quality=200 and URL  NOT LIKE 'index.%' GROUP BY date(umonth), URL order by day, m) p) group by p.day, p.m order by p.day,p.m;
