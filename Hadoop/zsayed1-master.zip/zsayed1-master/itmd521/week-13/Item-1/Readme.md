
I did map reduce with two techniques. First of all, I used substring method which is inefficient to some extend. In this case, it resulted inefficient while finding max Url for each month. As we can see that max(URL) for all the month is similar but when I compared it with my split method Mapper and Reducer, it came out that  ***MONTH Six has Different URL***. The screenshot of my analysis is as follows:-

***ITEM 1-1 order by month***(By subString for ***Large***)
![urlpermonth](https://cloud.githubusercontent.com/assets/25266333/25551516/908161d6-2c4b-11e7-9458-4f24d4b66635.PNG)
**Maps Recorded** : 31 maps were formed and 1 reducer.


***ITEM 1-2 order by day***(By substring for ***Large***)
![item1-2](https://cloud.githubusercontent.com/assets/25266333/25552790/35fe87f8-2c68-11e7-90b3-a25e18a5cf4e.PNG)
![item1-2-2](https://cloud.githubusercontent.com/assets/25266333/25552791/3713732e-2c68-11e7-85a1-dd5eacc34666.PNG)
![item1-2-3](https://cloud.githubusercontent.com/assets/25266333/25552792/380f2a84-2c68-11e7-93f2-4d714e836498.PNG)


** with Split fucntion by month on large and then small** 
![allsplit](https://cloud.githubusercontent.com/assets/25266333/25560935/f1313012-2d25-11e7-9646-7fe6bc235eca.PNG)
 
When we do it by split fucntion then we get different output which I think is the efficient once.

*****Analysis***** 
Average MAp time: As it created 35 maps on log files and only one job running on the cluster, the performance seemed to be rapid but when assumed in a huge cluster, the maps time will certanly increase, also increasing the average shuffle time and reduce time. Use of combiners and multiple reducers and mappers wil definately improve the overall time of trge job(Assumption).
