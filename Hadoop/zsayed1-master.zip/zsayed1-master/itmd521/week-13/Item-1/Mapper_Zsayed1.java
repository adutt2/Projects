import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mapper_Zsayed1
  extends Mapper<LongWritable, Text, Text, Text> {
 @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {
String line = value.toString();
String month, quality, URL;
try{
       month = line.substring(5, 7);
      quality = line.substring(123, 126);
    if (quality.matches("200")) {
    	 URL = line.substring(39, 50);
   context.write(new Text(month), new Text(URL));  
}
}
catch(StringIndexOutOfBoundsException ex){
	
//in order to skipp the gaps created by get method
 month = " ";
	 URL =" ";
	 quality = " ";
}
}
}
