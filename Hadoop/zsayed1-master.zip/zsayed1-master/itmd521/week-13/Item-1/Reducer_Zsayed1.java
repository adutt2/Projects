import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Reducer_Zsayed1
  extends Reducer<Text, Text, Text, Text> {
public static String sort(Z_arraystoringayList <String> list){
	String maximum = null;
	
	
	Map<String, Integer> Zmap = new HashMap<String, Integer>();

	for(int i = 0; i < list.size(); i++){
	   if(Zmap.get(list.get(i)) == null){
	      Zmap.put(list.get(i),1);
	   }else{
	      Zmap.put(list.get(i), Zmap.get(list.get(i)) + 1);
	   }
	}
	int greatest = 0;
	for (Entry<String, Integer> entry : Zmap.entrySet()) {
	   String key = entry.getKey();
	   int value = entry.getValue();
	   if( value > greatest){
	      greatest = value;
	   }
	}
	Z_arraystoringayList<Object> Z_arraystoring = new Z_arraystoringayList<Object>();
	for (Entry<String, Integer> entry : Zmap.entrySet()) {
	   String key = entry.getKey();
	   int value = entry.getValue();
	   if( value == greatest){
	       Z_arraystoring.add(key);
	       for (int k =0 ; k < Z_arraystoring.size(); k++){
	    	   maximum = (String) Z_arraystoring.get(k);
	    	   
	       }
	   }
	}
	
	return maximum;
	}
  public void reduce(Text key, Iterable<Text> values,
      Context context)
      throws IOException, InterruptedException {
String maximum = null;
Z_arraystoringayList<String> URL = new Z_arraystoringayList<String>();
for (Text value : values){
     URL.add(value.toString());
    }

        maximum=sort(URL);

    context.write(key, new Text(maximum));
  }

}
