**COMPARATIVE ANALYSIS**
 I have created an analysis based on key components which are adaptive as follows:-
 
 
 
 ***GATHERING***
 
 {
 
 **SETTING UP ENVIORNMENT**
 MapReduce, Hive, Scoop and Pig requires basic setups and configuration of .bashrc file but Mysql requires Classpath setup and basic installation in vagrant.It co-ordinated with jobs but it does not requires namenodes and datanodes.
 
***SETTING UP JOBS***
**MapReduce**: It requires Mapper and Reducer in order to traverse and sort into the file. It makes job easy by spliting the data in chunks and reducing it. It can be combined with combiners to improve the performance as we studied in week 7 and week 8, because it does half the job of reducers and thus AVERAGE REDUCE TIME decreases. There are three inputs to MapReduce jobs that is .txt, .gzip and .bzip extenstions. From which .Gzip form only one map and thus one reducer(*it can be used when the data is less along*).***Using gzip with combiners reducers the efficiency by incresing the time taken to complete the job***).To deal with large data bzip can be considered as it compresses the data 
in to chunks, as the map fucntion is over it compress  the data and thus **SHUFFLE TIME** reduces, But it does decompress it before giving it to the reducer.

**Mysql**
Mysql is completely different when compared to MapReduce. As they both work in different enviornment.It is very easy to setting up the job as it requires queries in a particular synntax and it traverses through a structure of database, on the otherhand** MapReduce **jobs travrse through unstructured data and that is why it is called ***Schema on Read***.

**SCOOP**
Scoop is similar to Hive but less the job setup requires feeding data code to it with MR jobs which is auto done by hive.


**HIVE**
Setting up job in is simple if one loads the data in to scoop and then import it into the hive enviornment. Hive is a blend of SQL and MapReduce. It basically provides structure for MapReduce Jobs. Setting up jobs for HIVE is simple as it requires hive command and then simple processing of queries like sql syntax. Basically it requires sql sysntax queries for setting up the job.

**PIG**
Setting up the jobs for pig requires input of script which is not known by many people. The best parr about pig is that we can use joints.

}


***PROCESSING***

{

**MApReduce**: I find processing of MapReduce most convinient as we can play with input(large.logs and small.logs) given to the maps and also we can use combiners and relate time with the use of different input files like text, gzip and bzip that varies map time and size parameters.Using combiners will decrease the processing time(assumption but experienced it in week7 and week 8 if the output is text sepearted by split function**assuming it for the .logs extention files**) )
MapReduce is simple to process as we can use channing of reducers or mappers. Also intermediate compressions and decompressions for processing large file.

**MySql**:
Mysql processing is simple,  we can use different predefined fucntions and subquueries to gain an output but it lags when the data is unstructured and large. Processing of  MySql is good with small and related data. To prpcess large and structured data we can use hive and Sqoop which helps in defragmenting the data, basically using mapReduce on STructured data \.

**SQOOP**:
Its processing is time consuming after the whole enviornment setup is done. After importing database from mysql we can perform schema on read on hdfs system.

**HIVE**:
Processing of hive is time consuming as compared to MR but more effiecient that sqoop. it took lot of time for large.log and small.log to copyinto database and then import it into sqoop and then import it in to HIVE.Hive does half the job of sqoop and then processes it using sql and does mapreduce on them. while in sqoop we need to give it java file to create mapreduce and process. 

**PIG**: Processing of pig is effiecient as compared to Hive because we can use complex queries with joints to work with multiple tables. The time taken by pig was more as comapared to Hive.(in my case)

}


***Ease of Coding to retrive ***

{

**MapReduce** : MapReduce requies java coding of simple files and parsing the data with the help of Mappers and Reducers to retrive data.


**MySQL** : MySql is the simplest form and easy as it SQL is known by most of the programmers to retrive data.

**SQOOP**: Scoop is basically interface between MySql and MR and can be done with sql as well as with the java job to retrive data.

**HIVE** : hive is sql once it is inserted into hive tables and simple to use as well to retrive data.

**PIG** Pig requires learning new script langauge and thus requires efforts in coding to retrive data and then uses map reduce.

}



***My Point of View for Item-1***

According to me if we convert the small.log  which was much larger in size can be combined with combiners and multiple mappers which will increase the maps and combiners doing half the jobs of reducers( assumption :But it may increase the shuffle time because 1 combiner and 1 reducer ). also if we convert log files in to .bz extension and then parse it with the help of combiners will probably increase the processing speed much faster.

