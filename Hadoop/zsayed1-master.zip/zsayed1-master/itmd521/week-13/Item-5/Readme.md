
![pig sorted](https://cloud.githubusercontent.com/assets/25266333/25561499/a85936ce-2d33-11e7-8fe4-c1138755a26f.PNG)


As pig requires latin script it took time for me to create the script and perform operations with rich data srtuctures. 
