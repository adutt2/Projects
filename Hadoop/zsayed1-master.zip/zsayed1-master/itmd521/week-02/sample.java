import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.sql.*;
import java.util.Calendar;

public class sample {
	public static void main(String[] args) throws Exception {
		 String myDriver = "org.gjt.mm.mysql.Driver";
	     String myUrl = "jdbc:mysql://localhost/sample?autoReconnect=true&useSSL=false";
	     Class.forName(myDriver);
	     Connection conn = DriverManager.getConnection(myUrl, "root", "password");
	    	String Temp;
		FileInputStream fis2 = new FileInputStream("/home/ubuntu/all/1990.gz");
		GZIPInputStream gis = new GZIPInputStream(fis2);
		//FileOutputStream fos2 = new FileOutputStream("/home/ubuntu/all/1990.csv");
		Reader decoder = new InputStreamReader(gis);
		BufferedReader br = new BufferedReader(decoder);
	
	String query="create table  sample (Year varchar (125), Weather_id varchar (125), wban varchar (125),Date varchar (125), hour varchar (125),unknwn varchar (125),latitude varchar (125),longitude varchar (125) ,unknown_1 varchar (125),elevation varchar (125),ph1 varchar (125),ph2 varchar (125),wind_direction varchar (125),qc1 varchar (125), ph3 varchar (125),ph4 varchar (125),ph5 varchar (125),ph6 varchar (125),sky_cieling varchar (125),phqc varchar (125),ph7 varchar (125),visibility varchar (125),qc2 varchar (125),ph8 varchar (125),qc3 varchar (125),dew_point varchar (125),qc4 varchar (125),atm_pressure varchar (125),qc5 varchar (125),temp varchar (125),ph9 varchar (125));";
 	
PreparedStatement preparedStmt = conn.prepareStatement(query);

	

		String line;
		while((line  = br.readLine()) != null){
		//System.out.println(line);
		String weather_id = line.substring(4,9);
		String Year = line.substring(15,19);
		if(line.charAt(87) == '+' && line.charAt(88) != '9')
		{
			 Temp =  line.substring(88, 92);
		}else
		{
		
		 Temp =  line.substring(87, 92);

		}
		String qc3= line.substring(92,93);

		//if( Temp != "9999" && qc3.matches("01459")){
		//Temp =  line.substring(88, 92);
		//System.out.println(Year);
		//System.out.println(Temp);

			
		
		String wban= line.substring(10,15);
		String date= line.substring(14,22);
		String hour= line.substring(23,27);
		String unknwn= line.substring(27,28);
		String latitude= line.substring(28,34);
		String longitude= line.substring(34,41);
		String unknwn1= line.substring(41,46);
		String elevation= line.substring(46,51);
		String ph1= line.substring(51,56);
		String ph2= line.substring(56,61);
		String wind_direction= line.substring(61,64);
		String qc1= line.substring(63,64);
		String ph3= line.substring(64,65);
		String ph4= line.substring(65,69);
		String ph5= line.substring(69,70);
		String ph6= line.substring(70,71);
		String sky_cieling= line.substring(71,76);
		String phqc= line.substring(76,77);
		String ph7= line.substring(77,78);
		String visiblity= line.substring(78,84);
		String qc2= line.substring(84,85);
		String ph8= line.substring(85,86);
		String ph9= line.substring(86,87);
		
		String dew_point= line.substring(93,98);
		String qc4= line.substring(98,99);
		String atm_pressure= line.substring(99,104);
		String qc5= line.substring(104,105);
	//	System.out.println(qc1);
		String query = "insert into  sample(Year, Weather_id, wban, Date, hour, unknwn, latitude, longitude, unknown_1, elevation, ph1, ph2, wind_direction, qc1, ph3, ph4, ph5, ph6, sky_cieling, phqc, ph7, visibility, qc2, ph8, qc3, dew_point, qc4, atm_pressure, qc5, temp, ph9) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
		PreparedStatement preparedStmt2 = conn.prepareStatement(query);
		 preparedStmt2.setString (1, Year);
	     preparedStmt.setString (2, weather_id);
	     preparedStmt.setString (3, wban);
	     preparedStmt.setString (4, date);
	     preparedStmt.setString (5, hour);
	     preparedStmt.setString (6, unknwn);
	     preparedStmt.setString (7, latitude);
	     preparedStmt.setString (8, longitude);
	     preparedStmt.setString (9, unknwn1);
	     preparedStmt.setString (10, elevation);
	     preparedStmt.setString (11, ph1);
	     preparedStmt.setString (12, ph2);
	     preparedStmt.setString (13, wind_direction);
	     preparedStmt.setString (14, qc1);
	     preparedStmt.setString (15, ph3);
	     preparedStmt.setString (16, ph4);
	     preparedStmt.setString (17, ph5);
	     preparedStmt.setString (18, ph6);
	     preparedStmt.setString (19, sky_cieling);
	     preparedStmt.setString (20, phqc);
	     preparedStmt.setString (21, ph7);
	     preparedStmt.setString (22, visiblity);
	     preparedStmt.setString (23, qc2);
	     preparedStmt.setString (24, ph8);
	     preparedStmt.setString (25, qc3);
	     preparedStmt.setString (26, dew_point);
	     preparedStmt.setString (27, qc4);
	     preparedStmt.setString (28, atm_pressure);
	     preparedStmt.setString (29, qc5);
	     preparedStmt.setString (30, Temp);
	     preparedStmt.setString (31, ph9);
	     preparedStmt.executeUpdate();
		}
	
	
}

}
