public class DBConnect { 

	//Connection object
	private static Connection connection;
	//Database connection parameters storing in tostirng can do it directly by passing vlaues in to 
    private static String url = "jdbc:mysql://www.papademas.net/fp";
    private static String username = "dbfp";
    private static String password = "510";

    public static Connection connect() throws SQLException{
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        }catch(ClassNotFoundException cnfe){
            System.err.println("Error: "+cnfe.getMessage());
        }catch(InstantiationException ie){
            System.err.println("Error: "+ie.getMessage());
        }catch(IllegalAccessException iae){
            System.err.println("Error: "+iae.getMessage());
        }

        connection = DriverManager.getConnection(url,username,password);
        return connection;
    }