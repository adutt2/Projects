1)copy sample.java to home
2)execute javac sample.java
3)execute java -Xmx2048m sample
4)if any error for path edit the path of 1990.gz file
5)if any error in creating table then create manual table by copying create(version 1) into mysql.
6)then run the sample.java for insertion.