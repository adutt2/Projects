# zsayed1
ITM Private Repo Zeshan Sayed
![img_5186](https://cloud.githubusercontent.com/assets/25266333/22312333/fac1c220-e31c-11e6-9c77-d41f633cbe10.JPG)
Hello,
My name is Zeshan. I come from Mumbai, biggest metropolis of India.
I did my undergraduate degree in Computer Science.
I am interested in Data analytics and mining.
Something interesting about me is that i love making unique cartoon sketch, that is what I  do in my leisure time. Also, I like watching movies,  TV series and sometimes playing football. 

